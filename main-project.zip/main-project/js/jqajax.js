$("#btnadd").click(function (e){
    e.preventDefault();
   // console.log("save button clicked");
 let nm=$("#nameid").val()
 let em=$("#emailid").val()
 let pm=$("#passwordid").val()

 mydata={name:nm,email:em,password:pm}
 //console.log(mydata);

 $.ajax({
    url:"insert.php",
    method:"POST",
    data:JSON.stringify(mydata),
    success:function(data){
        console.log(data);
    }

 })


});